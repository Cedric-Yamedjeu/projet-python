from crm import Users
import pytest
from tinydb import TinyDB, table
from tinydb.storages import MemoryStorage
import string

@pytest.fixture
def setup_up():
    Users.db = TinyDB(storage=MemoryStorage)

@pytest.fixture
def user(setup_up):
    u = Users(first_name="Martin",
              last_name="Smith",
              phone_number="0734763413",
              address="45 rue des chancres, 75000, paris")
    u.save()
    return u


def test_full_name(user):
    assert user.full_name == "Martin Smith"
    assert user.phone_number == "0734763413"
    assert user.address == "45 rue des chancres, 75000, paris"

def test_db_instance(user):
    assert isinstance(user.db_instance, table.Document)
    assert user.db_instance["first_name"] == "Martin"
    assert user.db_instance["last_name"] == "Smith"
    assert user.db_instance["phone_number"] == "0734763413"
    assert user.db_instance["address"] == "45 rue des chancres, 75000, paris"

def test_not_db_instance(setup_up):
    u = Users(first_name="Martin",
              last_name="Smith",
              phone_number="0734763413",
              address="45 rue des chancres, 75000, paris")
    assert u.db_instance is None


def test_exists(user):
    assert user.exists() is True

def test_delete(setup_up):
    u = Users(first_name="Martin",
              last_name="Smith",
              phone_number="0734763413",
              address="45 rue des chancres, 75000, paris")
    #u.save()
    u.delete()
    assert u.exists() is False

def test__check_phone_numbers(user):
    assert len(user.phone_number) >= 10
    assert user.phone_number.isdigit() is True

def test__not_check_phone_number():
    u = Users(first_name="Martin",
              last_name="Smith",
              phone_number="+7H4kk63413",
              address="45 rue des chancres, 75000, paris")
    assert u.phone_number.isdigit() is False

def test_not_len_check_phone_number():
    u = Users(first_name="Martin",
              last_name="Smith",
              phone_number="+567888",
              address="45 rue des chancres, 75000, paris")
    with pytest.raises(ValueError) as err:
        u._check_phone_numbers()
    assert "invalide" in str(err.value)


def test__check_names(user):
    assert user.first_name == "Martin"
    assert user.last_name == "Smith"
    assert string.punctuation not in user.full_name
    assert string.digits not in user.full_name

def test_check_names_empty(user):
    u = Users(first_name="",
              last_name="",
              phone_number="0734763413",
              address="45 rue des chancres, 75000, paris")

    with pytest.raises(ValueError) as err:
        u._check_names()
    assert "obligatoire" in str(err.value)


def test_save():
    u_first = Users(first_name="Francois",
              last_name="Xavier",
              phone_number="0734763445",
              address="5 rue des chancres, 75000, paris")
    u_second = Users(first_name="Francois",
              last_name="Xavier",
              phone_number="0734763445",
              address="5 rue des chancres, 75000, paris")

    first = u_first.save()
    second = u_second.save()
    assert isinstance(first, int)
    assert first > 0

    assert second is None